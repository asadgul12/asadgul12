﻿using Asp.NetRedisCache.Models;
using Asp.NetRedisCache.Queries;
using Asp.NetRedisCache.Services;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Asp.NetRedisCache.Handler
{
    public class GetEmployeesListHandler : IRequestHandler<GetAllEmployeesAsync, List<Employee>>
    {
        private IEmployeeService employeeService;
        public GetEmployeesListHandler(IEmployeeService employeeService)
        {
            this.employeeService = employeeService;
        }
        public async Task<List<Employee>> Handle(GetAllEmployeesAsync request, CancellationToken cancellationToken)
        {
         return await  employeeService.GetAllEmployeesAsync();
        }
    }
}
