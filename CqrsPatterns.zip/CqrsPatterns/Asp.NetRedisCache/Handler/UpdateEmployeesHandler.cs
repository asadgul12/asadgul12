﻿using Asp.NetRedisCache.Commands;
using Asp.NetRedisCache.Models;
using Asp.NetRedisCache.Services;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Asp.NetRedisCache.Handler
{
    public class UpdateEmployeesHandler : IRequestHandler<UpdateEmployee, int>
    {
        private IEmployeeService _employeeService;
        public UpdateEmployeesHandler(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }
        public async Task<int> Handle(UpdateEmployee request, CancellationToken cancellationToken)
        {
            return await _employeeService.UpdateEmployeeAsync(new Employee
            {
                ID=request.ID,
                Address=request.Address,
                Email=request.Email,
                Name=request.Name
            });
        }
    }
}
