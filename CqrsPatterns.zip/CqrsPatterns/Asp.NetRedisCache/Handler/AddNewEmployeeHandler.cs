﻿using Asp.NetRedisCache.Commands;
using Asp.NetRedisCache.Models;
using Asp.NetRedisCache.Services;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Asp.NetRedisCache.Handler
{
    public class AddNewEmployeeHandler : IRequestHandler<AddEmployees, Employee>
    {
        private IEmployeeService _employeeService;
        public AddNewEmployeeHandler(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }
        public async Task<Employee> Handle(AddEmployees request, CancellationToken cancellationToken)
        {
            return await _employeeService.AddNewEmployeeAsync(new Employee
            {
                Address=request.Address,
                Email=request.Email,
                Name=request.Name               
            });            
        }
    }
}
