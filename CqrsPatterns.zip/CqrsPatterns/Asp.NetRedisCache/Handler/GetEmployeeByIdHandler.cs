﻿using Asp.NetRedisCache.Models;
using Asp.NetRedisCache.Queries;
using Asp.NetRedisCache.Services;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Asp.NetRedisCache.Handler
{
    public class GetEmployeeByIdHandler : IRequestHandler<GetEmployeeById, Employee>
    {
        private IEmployeeService _employeeService;
        public GetEmployeeByIdHandler(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }
        public async Task<Employee> Handle(GetEmployeeById request, CancellationToken cancellationToken)
        {
            return await _employeeService.GetEmployeeByIDAsync(request.ID);
        }
    }
}
