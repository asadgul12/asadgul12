﻿using Asp.NetRedisCache.Databases;
using Asp.NetRedisCache.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asp.NetRedisCache.Services
{
    public class EmployeeService : IEmployeeService
    {
        DatabaseClass dbclass;
        public EmployeeService(DatabaseClass databaseClass)
        {
            dbclass = databaseClass;
        }
        public async Task<Employee> AddNewEmployeeAsync(Employee employee)
        {
            var currentrecord=   dbclass.Employees.Add(employee);
            await dbclass.SaveChangesAsync();
            return currentrecord.Entity;
        }

        public async Task<int> DeleteEmployeeAsync(int id)
        {
            var getemp = dbclass.Employees.Where(x => x.ID == id).FirstOrDefault();
            if (getemp == null)
                return -1;
            dbclass.Employees.Remove(getemp);
            return await dbclass.SaveChangesAsync();   
        }

        public async Task<List<Employee>> GetAllEmployeesAsync()
        {
            return await dbclass.Employees.ToListAsync();
        }

        public async Task<Employee> GetEmployeeByIDAsync(int id)
        {
            return await dbclass.Employees.Where(x => x.ID == id).FirstOrDefaultAsync();
        }

        public async Task<int> UpdateEmployeeAsync(Employee employee)
        {
            var getemp = dbclass.Employees.Where(x => x.ID == employee.ID).FirstOrDefault();
            if (getemp == null)
                return -1;
            Employee emp = new Employee
            {
                Address=employee.Address,
                Name=employee.Name,
                Email=employee.Email
            };
            dbclass.Employees.Update(emp);
            return await dbclass.SaveChangesAsync(); 
        }        
    }
}
