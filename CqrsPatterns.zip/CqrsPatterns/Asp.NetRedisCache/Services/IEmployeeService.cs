﻿using Asp.NetRedisCache.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asp.NetRedisCache.Services
{
    public interface IEmployeeService
    {
       
        Task<List<Employee>> GetAllEmployeesAsync();

        Task<Employee> GetEmployeeByIDAsync(int id);

        Task<Employee> AddNewEmployeeAsync(Employee employee);

        Task<int> UpdateEmployeeAsync(Employee employee);

        Task<int> DeleteEmployeeAsync(int id);

    }
}
