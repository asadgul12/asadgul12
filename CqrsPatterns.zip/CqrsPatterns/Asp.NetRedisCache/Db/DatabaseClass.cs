﻿using Asp.NetRedisCache.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asp.NetRedisCache.Databases
{
    public class DatabaseClass:DbContext
    {
        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    base.OnConfiguring(optionsBuilder);
        //    optionsBuilder.UseSqlServer(@"Server=CP-L160\FUSION;Database=CafeSystem;Trusted_Connection=true;TrustServerCertificate=true");
        //}
        public DatabaseClass(DbContextOptions<DatabaseClass> dbContextOptions) : base(dbContextOptions)
        {

        }

        public DbSet<Employee> Employees { get; set; }

    }
}
