﻿using Asp.NetRedisCache.Commands;
using Asp.NetRedisCache.Models;
using Asp.NetRedisCache.Queries;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asp.NetRedisCache.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        IMediator mediator;
        public HomeController(IMediator mediator)
        {
            this.mediator = mediator;
        }
        [HttpGet("GetAllEmployee")]
        public async Task<List<Employee>> GetAllEmployee()
        {
            var getemplist =await mediator.Send(new GetAllEmployeesAsync());
            return getemplist;
        }

        [HttpPost("AddAllEmployee")]
        public async Task<Employee> AddAllEmployee(Employee employee)
        {
            var getemplist = await mediator.Send(new AddEmployees(employee.ID,employee.Name,employee.Address,employee.Email));
            return getemplist;
        }
    }
}
