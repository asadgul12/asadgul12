﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asp.NetRedisCache.Commands
{
    public class RemoveEmployee:IRequest<int>
    {
        public int ID { get; set;}
    }
}
