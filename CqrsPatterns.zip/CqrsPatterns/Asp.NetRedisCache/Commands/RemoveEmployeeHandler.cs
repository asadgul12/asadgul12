﻿using Asp.NetRedisCache.Services;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Asp.NetRedisCache.Commands
{
    public class RemoveEmployeeHandler : IRequestHandler<RemoveEmployee, int>
    {
        private IEmployeeService _employeeService;
        public RemoveEmployeeHandler(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }
        public async Task<int> Handle(RemoveEmployee request, CancellationToken cancellationToken)
        {
          return await _employeeService.DeleteEmployeeAsync(request.ID);
        }
    }
}
