﻿using Asp.NetRedisCache.Models;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asp.NetRedisCache.Commands
{
    public class UpdateEmployee:IRequest<int>
    {
        public UpdateEmployee(int ID,string Name, string address, string email)
        {
             this.ID = ID;
            this.Name = Name;
            Address = address;
            Email = email;
        }
      public int ID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
    }
}
