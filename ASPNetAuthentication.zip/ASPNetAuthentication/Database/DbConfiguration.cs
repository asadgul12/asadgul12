﻿using ASPNetAuthentication.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ASPNetAuthentication.IdentityClasses;
using Microsoft.AspNetCore.Identity;

namespace ASPNetAuthentication.Database
{
    public class DbConfiguration:IdentityDbContext<ApplicationUser,ApplicationRole,String>
    {
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }
        public DbConfiguration(DbContextOptions<DbConfiguration> dbContextOptions):base(dbContextOptions)
        {

        }
        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseSqlServer(@"Server=CP-L160\FUSION;Database=Learning;Trusted_Connection=true;TrustServerCertificate=true");
        //}
        public DbSet<UserRegistration> UserRegistrations { get; set; }
        public DbSet<IdentityRole> Roles { get; set; }
        public DbSet<Projects> Projects { get; set; }

    }
}
