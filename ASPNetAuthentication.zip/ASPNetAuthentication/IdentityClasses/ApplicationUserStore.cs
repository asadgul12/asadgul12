﻿using ASPNetAuthentication.Database;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPNetAuthentication.IdentityClasses
{
    public class ApplicationUserStore:UserStore<ApplicationUser>
    {
        public ApplicationUserStore(DbConfiguration dbConfiguration):base(dbConfiguration)
        {

        }
    }
}
