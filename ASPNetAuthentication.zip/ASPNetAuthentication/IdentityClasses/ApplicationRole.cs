﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ASPNetAuthentication.IdentityClasses
{
    public class ApplicationRole:IdentityRole<String>
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key] // Ensure that the [Key] attribute is applied to the primary key property
        public string Id { get; set; }
    }
}
