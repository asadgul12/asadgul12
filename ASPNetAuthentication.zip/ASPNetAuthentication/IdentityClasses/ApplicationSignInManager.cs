﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace ASPNetAuthentication.IdentityClasses
{
    public class ApplicationSignInManager:SignInManager<ApplicationUser>
    {
        public ApplicationSignInManager
            (ApplicationUserManager applicationUserManager,
            IHttpContextAccessor httpContextAcccessor,
            IUserClaimsPrincipalFactory<ApplicationUser> userClaimsPrincipalFactory,
            IOptions<IdentityOptions> options,
            ILogger<ApplicationSignInManager> logger,
            IAuthenticationSchemeProvider schemeProvide, IUserConfirmation<ApplicationUser> confirmation) : base
            (applicationUserManager, httpContextAcccessor, userClaimsPrincipalFactory, options, logger, schemeProvide, confirmation)
        {

        }
    }
}
