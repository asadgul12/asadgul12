﻿using ASPNetAuthentication.IdentityClasses;
using ASPNetAuthentication.Models;
using ASPNetAuthentication.ViewModels;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace ASPNetAuthentication.Services
{
    public class UserServices : IUserServices
    {
        private readonly ApplicationUserManager _applicationusermanager;
        private readonly ApplicationSignInManager _applicationusersigninmanager;
        private readonly AppSettings _appsettings;
        public UserServices(ApplicationUserManager _applicationusermanager, ApplicationSignInManager _applicationusersigninmanager,IOptions<AppSettings> options)
        {
            this._applicationusermanager = _applicationusermanager;
            this._applicationusersigninmanager = _applicationusersigninmanager;
            _appsettings = options.Value;
        }
        public async Task<ApplicationUser> AuthenticateUser(LoginViewModel loginViewModel)
        {
            var user = await _applicationusersigninmanager.PasswordSignInAsync(loginViewModel.UserName, loginViewModel.Password, false,false); ;
            if(user.Succeeded)
            {
                var applicationUser = await _applicationusermanager.FindByNameAsync(loginViewModel.UserName);
         //       applicationUser.PasswordHash = null;
                var tokenhanlder = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(_appsettings.Secret);
                var tokenDescriptor = new SecurityTokenDescriptor()
                {
                    Subject = new ClaimsIdentity(new Claim[] {
        new Claim(ClaimTypes.Name, applicationUser.Id),
        new Claim(ClaimTypes.Email, applicationUser.Email),
        new Claim(ClaimTypes.UserData, applicationUser.PasswordHash),

    }),
                    Expires = DateTime.UtcNow.AddHours(8),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                };
                var token = tokenhanlder.CreateToken(tokenDescriptor);
                var tokenString = tokenhanlder.WriteToken(token);
                applicationUser.Token = tokenString;
                return applicationUser;

            }
            return null;
        }
    }
}
