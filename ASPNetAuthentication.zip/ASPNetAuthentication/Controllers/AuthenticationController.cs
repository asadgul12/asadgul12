﻿using ASPNetAuthentication.Database;
using ASPNetAuthentication.Models;
using ASPNetAuthentication.Services;
using ASPNetAuthentication.ViewModels;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPNetAuthentication.Controllers
{
  //  [EnableCors("AllowOrigin")]
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private DbConfiguration dbConfiguration;
        private IUserServices userServices;
        public AuthenticationController(IUserServices userServices)
        {
            this.userServices = userServices;
          //  dbConfiguration = Db;
        }
      //  [Route("RegisterUser")]
        [HttpPost("RegisterUser")]
        public IActionResult RegisterUser(UsersRegistrationDTO usersRegistrationDTO)
        {          
            UserRegistration userRegistration = new UserRegistration();
            userRegistration.Name = usersRegistrationDTO.Name;
            userRegistration.Email = usersRegistrationDTO.Email;
            userRegistration.password = usersRegistrationDTO.password;
            userRegistration.confirmpassword = usersRegistrationDTO.confirmpassword;
            dbConfiguration.UserRegistrations.Add(userRegistration);
            dbConfiguration.SaveChanges();
            return Ok();
        }
        [HttpPost("Authenticate")]
        //[Route("authenticate")]
        public async Task<IActionResult> Authenticate([FromBody]LoginViewModel loginViewModel)
        {
            var authenticate = await userServices.AuthenticateUser(loginViewModel);
            if(authenticate==null)
            {
                return BadRequest(new { message="UserName or Password in Incorrect"});
            }
            return Ok(authenticate);
        } 
        [HttpGet("GetUser")]
        public IActionResult GetUser()
        {
                  
            return Ok(dbConfiguration.UserRegistrations.FirstOrDefault());
        }

        [HttpGet("GetProjects")]
        public List<Projects> GetProjects()
        {
       
            return dbConfiguration.Projects.ToList();        
        }
        //[EnableCors("AllowOrigin")]

        //[Route("api/AddProjects")]
        [HttpPost("AddProjects")]
        public void AddProjects([FromBody]Projects projects)
        {           
            dbConfiguration.Projects.Add(projects);
            dbConfiguration.SaveChanges();
        }
    }
}
